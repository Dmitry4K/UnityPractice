using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ReturningSliderScript : MonoBehaviour, IPointerExitHandler
{
    [SerializeField]
    private Slider slider;

    private float startValue = 0;

    public void Start()
    {
        startValue = slider.value;
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        slider.value = startValue;
    }
}
