using UnityEngine;

public class LookRotation : MonoBehaviour
{
    private Vector3 lookPosition;
    private Quaternion startRotation;
    public float distance = 10.0f;
    void Start()
    {
        startRotation = gameObject.transform.rotation;
        lookPosition = gameObject.transform.position;
        lookPosition.z += distance;
    }


    void Update()
    {
        gameObject.transform.LookAt(lookPosition);
        gameObject.transform.rotation *= startRotation;
    }
}
