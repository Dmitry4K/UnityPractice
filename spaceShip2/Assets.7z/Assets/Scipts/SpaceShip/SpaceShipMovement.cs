using UnityEngine;

public class SpaceShipMovement : MonoBehaviour
{
    // Start is called before the first frame update
    private Vector3 startPosition;
    public FixedJoystick joystick;

    [SerializeField]
    private float sensitivity = 1.0f;
    [SerializeField]
    private float horizontalMultiplyer = 1.0f;
    [SerializeField]
    private float verticalMultiplyer = 1.0f;

    [SerializeField]
    private float maxRadius = 4.0f;
    void Start()
    {
        startPosition = gameObject.transform.position;
    }


    void Update()
    {
        Vector3 curPosition = gameObject.transform.position;
        curPosition.x += joystick.Horizontal * sensitivity * horizontalMultiplyer;
        curPosition.y += joystick.Vertical * sensitivity * verticalMultiplyer;
        float distanceToStart = (curPosition - startPosition).magnitude;

        if (distanceToStart > maxRadius)
        {
            curPosition = startPosition + (curPosition - startPosition) * maxRadius / distanceToStart;
        }

        gameObject.transform.position = curPosition;
    }
}
