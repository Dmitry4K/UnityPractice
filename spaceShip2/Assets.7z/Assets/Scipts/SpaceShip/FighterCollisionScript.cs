using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class FighterCollisionScript : MonoBehaviour
{
    [SerializeField]
    private ParticleSystem collisionParticleSystem;

    [SerializeField]
    private ParticleSystem destroyRockParticleSystem;

    [SerializeField]
    private TextMeshProUGUI text;

    [SerializeField]
    private TextMeshProUGUI textMaxAliveTIme;

    private float startTime;
    private float maxAliveTime = 0.00f;

    private void Start()
    {
        startTime = Time.time;
        SetMaxAliveTime();
    }

    private void Update()
    {
        float curTimeAlive = Time.time - startTime;
        text.text = $"{curTimeAlive.ToString("0.00")} sec";
        if (curTimeAlive > maxAliveTime)
        {
            maxAliveTime = curTimeAlive;
            SetMaxAliveTime();
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("hited by asteroid!");
        maxAliveTime = Mathf.Max(maxAliveTime, Time.time - startTime);
        startTime = Time.time;
        SetMaxAliveTime();
        foreach (ContactPoint point in collision.contacts)
        {
            Instantiate(collisionParticleSystem, point.point, Random.rotation);
            Instantiate(destroyRockParticleSystem, collision.gameObject.transform.position, Quaternion.Euler(new Vector3(-180, 0, 0)));
        }
        Destroy(collision.gameObject);
    }

    private void SetMaxAliveTime()
    {
        textMaxAliveTIme.text = $"Best Time: {maxAliveTime.ToString("0.00")}";
    }
}
