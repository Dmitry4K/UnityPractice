using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class TorusSpawnAsteroidsScripts : MonoBehaviour
{
    public Torus torusObject;
    public List<GameObject> toSpawnObjects;
    public float spawnDelayTime = 1.0f;
    private float lastSpawnTime = 0.0f;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Time.time - lastSpawnTime > spawnDelayTime)
        {
            lastSpawnTime = Time.time;
            spawnObjects(Random.Range(4, 12));
        }
    }

    private void spawnObject()
    {
        GameObject objToSpawn = toSpawnObjects[Random.Range(0, toSpawnObjects.Count)];
        Vector3 posToSpawn = new()
        {
            x = Random.Range(-3.0f, 3.0f),
            y = 0 + Random.Range(-3.0f, 3.0f),
            z = 63.0f + Random.Range(-3.0f, 3.0f)
        };
        Instantiate(objToSpawn, posToSpawn, Random.rotation, torusObject.transform);
    }

    private void spawnObjects(int count)
    {
        for (int i = 0;i<count;++i)
        {
            spawnObject();
        }
    }
}
