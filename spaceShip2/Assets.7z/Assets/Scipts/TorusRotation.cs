using UnityEngine;
using UnityEngine.UI;

public class TorusRotation : MonoBehaviour
{
    public Slider speedSlider;
    public float sensitivity = 1.0f;
    Vector3 startAngles;
    private void Start()
    {
        startAngles = gameObject.transform.rotation.eulerAngles;
    }
    void Update()
    {
        gameObject.transform.rotation = gameObject.transform.rotation * Quaternion.Euler(0.0f, speedSlider.value * sensitivity, 0.0f);
    }
}
