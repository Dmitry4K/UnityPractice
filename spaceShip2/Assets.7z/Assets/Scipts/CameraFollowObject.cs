using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CameraFollowObject : MonoBehaviour
{
    private Camera m_Camera;
    public Transform followObject;
    void Start()
    {
        m_Camera = GetComponent<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        m_Camera.transform.LookAt(followObject);
    }
}
