using UnityEngine;

public class DestroyByXScript : MonoBehaviour
{

    // Update is called once per frame
    void Update()
    {
        if(gameObject.transform.position.x < -10.0f)
        {
            Destroy(this);
        }
    }
}
